from pyodide import console as _pyodide_console  # type: ignore
from pyodide.console import _CommandCompiler, CodeRunner, _WriteStream  # type: ignore
import js  # type: ignore
from . import kernel
import sys
import traceback
import ast
import random
import linecache

__author__ = "Romain Casati"
__license__ = "GNU GPL v3"
__email__ = "romain.casati@basthon.fr"


__all__ = ["InteractiveConsole"]

#################################
# pyodide.console monkey-patches
#################################

# force 'exec' mode (forced to 'single' by Pyodide, so monkey-patch!)
# See: https://github.com/pyodide/pyodide/blob/main/src/py/pyodide/console.py#L196
# See: https://docs.python.org/fr/3/library/codeop.html

_call = _CommandCompiler.__call__


def __call(self, source, filename, symbol):
    return _call(self, source, filename, "exec")


_CommandCompiler.__call__ = __call


def patch_compile_input_sleep():
    """
    Monkey-patch pyodide.console.CodeRunner to modify the ast before compiling the commands or
    statements, replacing:
    * calls to `input` with `await _basthon_input_async`
    * calls to `sleep` with `await _basthon_sleep_async`
    * calls to `time.sleep` with `await _basthon_sleep_async`

    This logic is not applied if `js.basthon.syncCommSupport()` is true.

    WARNING: aliases/intermediate variables and calls inside functions or class definitions are
    not handled:

        ```python
        f = input
        s = f("what!?")         # Won't be handled

        import time as T
        T.sleep(1000)           # Won't be handled

        def something():
            s = input(...)      # Won't be modified (same with sleep)

        class Thing:
            s = input(...)      # Won't be modified (same with sleep)
            def method(self):
                s = input(...)  # Won't be modified (same with sleep)
        ```
    """
    if js.basthon.syncCommSupport():
        return

    def patched_compile(self, *args, **kwargs):
        self.ast = RewriteAST().visit(self.ast)
        return _unpatched_compile(self, *args, **kwargs)

    _unpatched_compile = CodeRunner.compile
    CodeRunner.compile = patched_compile

    def is_call_to(name: str, node: ast.AST):
        return isinstance(node, ast.Name) and node.id == name

    def is_attr_of(obj: str, attr: str, node: ast.AST):
        return (
            isinstance(node, ast.Attribute)
            and node.attr == attr
            and hasattr(node.value, "id")
            and node.value.id == obj
        )

    class RewriteAST(ast.NodeTransformer):
        """
        Mutate the given AST tree to automatically transform calls to `input(...)`, `sleep(...)`
        or `time.sleep(...)` that are done at module level in async calls to the related Basthon
        function: `_basthon_input_async` or `_basthon_sleep_async`.

        - Calls inside other functions or in classes or lambda are left untouched.

        - Aliases are ignored. Examples:
            f=input; f()
            import time as T; T.sleep()
        """

        _input_async_name = "_basthon_input_async"
        _sleep_async_name = "_basthon_sleep_async"

        def visit_Call(self, node: ast.Call):
            func = node.func
            set_await = True

            if is_call_to("input", func):  # input(...)
                func.id = self._input_async_name
            elif is_call_to("sleep", func):  # sleep(...)
                func.id = self._sleep_async_name
            elif is_attr_of("time", "sleep", func):  # time.sleep(...)
                node.func = ast.Name(self._sleep_async_name, func.ctx)
            else:  # No modifications
                set_await = False

            if set_await:
                node = ast.Await(node)

            self.generic_visit(node)
            return node

        def _ignore(self, node):
            """Do not explore recursively these nodes"""
            return node

        visit_FunctionDef = _ignore
        visit_Lambda = _ignore
        visit_ClassDef = _ignore


patch_compile_input_sleep()

# this is absent from Pyodide and is e.g. needed by doctest
_WriteStream.encoding = "utf8"


class InteractiveConsole(_pyodide_console.PyodideConsole):
    """
    This is the Python's part of Basthon kernel.

    See: https://github.com/pyodide/pyodide/blob/main/src/py/pyodide/console.py#L593
    """

    def __init__(self, *args, **kwargs):
        self.execution_count = None
        kwargs["globals"] = kwargs.get("globals", sys.modules["__main__"].__dict__)
        kwargs["filename"] = kwargs.get("filename", "<input>")
        kwargs["persistent_stream_redirection"] = True

        # setup persistent streams redirection
        def stdout_callback(text):
            if getattr(self, "_stdout_callback", None) is not None:
                return self._stdout_callback(text)
            else:
                js.console.log(text)

        kwargs["stdout_callback"] = stdout_callback

        def stderr_callback(text):
            if getattr(self, "_stderr_callback", None) is not None:
                return self._stderr_callback(text)
            else:
                js.console.error(text)

        kwargs["stderr_callback"] = stderr_callback

        super().__init__(*args, **kwargs)
        self.locals = self.globals
        self.start()

    # overload to fix filename not taken into account
    def num_frames_to_keep(self, tb):
        import traceback

        keep_frames = False
        kept_frames = 0
        # Try to trim out stack frames inside our code
        for frame, _ in traceback.walk_tb(tb):
            keep_frames = keep_frames or frame.f_code.co_filename == self.filename
            keep_frames = keep_frames or frame.f_code.co_filename == "<exec>"
            if keep_frames:
                kept_frames += 1
        return kept_frames

    def banner(self):
        """REPL banner. Taken from PyodideConsole."""
        return _pyodide_console.BANNER

    def roll_in_history(self, code):
        """Manage storing in 'In' ala IPython."""
        self.locals["In"].append(code)

    def roll_out_history(self, out):
        """Manage storing in 'Out', _, __, ___ ala IPython."""
        outputs = self.locals["Out"]
        # out is not always stored
        if out is not None and out is not outputs:
            outputs[self.execution_count] = out
            self.locals["___"] = self.locals["__"]
            self.locals["__"] = self.locals["_"]
            self.locals["_"] = out

    def start(self):
        """
        Start the Basthon kernel and fill the namespace.
        """
        self.execution_count = 0
        linecache.clearcache()
        self.locals.clear()
        self.locals.update(
            {
                "__name__": "__main__",
                "__doc__": None,
                "_": "",
                "__": "",
                "___": "",
                "In": [""],
                "Out": {},
            }
        )
        # remember loaded modules at start
        self._modules = set(sys.modules.keys())

    def stop(self):
        """
        Stop the Basthon kernel.
        """
        # delete modules imported during session
        excluded = {"setuptools", "numpy"}  # modules that dislike being loaded twice
        for module in set(sys.modules.keys()) - self._modules:
            if module.split(".")[0] not in excluded:
                del sys.modules[module]

    def restart(self):
        """
        Restart the Basthon kernel.
        """
        self.stop()
        self.start()

    def more(self, source):
        """Is the source ready to be evaluated or want we more?

        Useful to set ps1/ps2 for terminal prompt.
        """
        # backup std callbacks to ignore syntax warnings
        stdout_cb = getattr(self, "_stdout_callback", None)
        stderr_cb = getattr(self, "_stderr_callback", None)
        self._stdout_callback = lambda *args, **kwargs: None
        self._stderr_callback = self._stdout_callback

        try:
            code = self._compile(source, self.filename, "exec")
        except (OverflowError, SyntaxError, ValueError):
            return False
        finally:
            # restoring
            if stdout_cb is not None:
                self._stdout_callback = stdout_cb
            if stderr_cb is not None:
                self._stderr_callback = stderr_cb

        if code is None:
            return True

        if "\n" in source:
            return not source.endswith("\n")

        return False

    async def eval(self, code, stdout_callback, stderr_callback, data=None):
        """
        Evaluation of Python code with communication management with the JS part of Basthon and
        stdout/stderr catching. `data` can be accessed in code through '__eval_data__' variable
        in global namespace.

        Results:
        --------
        A promise that resolves with the formatted result.
        """
        self.locals["__eval_data__"] = data.to_py()
        self.execution_count += 1
        self._stdout_callback = stdout_callback
        self._stderr_callback = stderr_callback
        with kernel.preserve_random_state():
            self.filename = f"<basthon-input-{self.execution_count}-{random.randrange(16**12):012x}>"
        linecache.cache[self.filename] = (
            len(code),
            None,
            [line + "\n" for line in code.splitlines()],
            self.filename,
        )

        self.roll_in_history(code)

        fut = self.runsource(code, self.filename)
        try:
            result = await fut
        except Exception:
            return fut.formatted_error
        # if fut is incomplete, we should raise an error so recompile
        if fut.syntax_check == "incomplete":
            try:
                self._compile.compiler(code, self.filename, "exec")
            except Exception as e:
                if e.__traceback__:
                    traceback.clear_frames(e.__traceback__)
                return self.formatsyntaxerror(e)
            raise RuntimeError("Internal Basthon error")

        self.roll_out_history(result)
        if result is not None:
            result = kernel.format_repr(result)
        return result, self.execution_count
